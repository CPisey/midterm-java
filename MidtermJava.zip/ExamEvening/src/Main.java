import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

class ShortDateConverter {
    public static void main(String[] args) {
        // Ask the user to enter a short date
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a short date (YYYY-MM-DD): ");
        String shortDate = scanner.nextLine();
        scanner.close();

        // Extract year, month, and day from the short date
        int year = Integer.parseInt(shortDate.substring(0, 4));
        int month = Integer.parseInt(shortDate.substring(5, 7));
        int day = Integer.parseInt(shortDate.substring(8, 10));

        // Convert month number to month name
        String monthName = getMonthName(month);

        // Create a LocalDate object with the extracted year, month, and day
        LocalDate date = LocalDate.of(year, month, day);

        // Format the date as "MonthName day, year"
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
        String fullDate = date.format(formatter);

        // Display the full date representation
        System.out.println("Full date: " + fullDate);
    }

    private static String getMonthName(int month) {
        String[] monthNames = {"January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"};
        return monthNames[month - 1];
    }
}